(()=>{var e={};e.id=613,e.ids=[613],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11723:e=>{"use strict";e.exports=require("querystring")},12412:e=>{"use strict";e.exports=require("assert")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28163:(e,t,r)=>{"use strict";r.d(t,{Q:()=>i});var n=r(6475);let i=(0,n.createServerReference)("7f6402368c93ce36c03b85af4e7d8082b65685da00",n.callServer,void 0,n.findSourceMapURL,"revalidateSyncTags")},28354:e=>{"use strict";e.exports=require("util")},28534:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>l.a,__next_app__:()=>p,pages:()=>c,routeModule:()=>d,tree:()=>u});var n=r(65239),i=r(48088),s=r(88170),l=r.n(s),o=r(30893),a={};for(let e in o)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(a[e]=()=>o[e]);r.d(t,a);let u={children:["",{children:["(Routes)",{children:["blog",{children:["[slug]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,78460)),"C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\(Routes)\\blog\\[slug]\\page.tsx"]}]},{}]},{}]},{forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,46055))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(r.bind(r,32007)),"C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\layout.tsx"],loading:[()=>Promise.resolve().then(r.bind(r,99766)),"C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\loading.tsx"],"not-found":[()=>Promise.resolve().then(r.bind(r,82366)),"C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\not-found.tsx"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,46055))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,c=["C:\\Users\\Muse\\Desktop\\up_work_files\\HabeshaTech\\mamigas\\mamigas\\app\\(Routes)\\blog\\[slug]\\page.tsx"],p={require:r,loadChunk:()=>Promise.resolve()},d=new n.AppPageRouteModule({definition:{kind:i.RouteKind.APP_PAGE,page:"/(Routes)/blog/[slug]/page",pathname:"/blog/[slug]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:u}})},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},29759:(e,t,r)=>{"use strict";r.r(t),r.d(t,{"7f263e4bd53ae124d07bdf6f6b0c27dafd3ccc0072":()=>i.q,"7f6402368c93ce36c03b85af4e7d8082b65685da00":()=>n.Q,"7ff5e5f7fb56f0e82c3f4fdcd1c074efb59a5a1991":()=>n.L});var n=r(34360),i=r(95075)},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},41171:(e,t,r)=>{Promise.resolve().then(r.bind(r,98715)),Promise.resolve().then(r.bind(r,84453)),Promise.resolve().then(r.bind(r,66112)),Promise.resolve().then(r.t.bind(r,85814,23)),Promise.resolve().then(r.t.bind(r,79167,23))},52648:(e,t,r)=>{"use strict";r.d(t,{i:()=>l});var n=r(99902),i=r(23777);let s=r.n(i)()(n.S);function l(e){return s.image(e)}},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64731:(e,t,r)=>{Promise.resolve().then(r.bind(r,58481)),Promise.resolve().then(r.bind(r,46420)),Promise.resolve().then(r.bind(r,43946)),Promise.resolve().then(r.t.bind(r,4536,23)),Promise.resolve().then(r.t.bind(r,47429,23))},74075:e=>{"use strict";e.exports=require("zlib")},77598:e=>{"use strict";e.exports=require("node:crypto")},78460:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>G});var n=r(37413),i=r(27810),s=r(88202),l=r(52648);function o(e,t){var r=Object.keys(e);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(e);t&&(n=n.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),r.push.apply(r,n)}return r}function a(e){for(var t=1;t<arguments.length;t++){var r=null!=arguments[t]?arguments[t]:{};t%2?o(Object(r),!0).forEach(function(t){var n,i,s;n=e,i=t,s=r[t],(i=function(e){var t=function(e,t){if("object"!=typeof e||!e)return e;var r=e[Symbol.toPrimitive];if(void 0!==r){var n=r.call(e,t||"default");if("object"!=typeof n)return n;throw TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(e,"string");return"symbol"==typeof t?t:t+""}(i))in n?Object.defineProperty(n,i,{value:s,enumerable:!0,configurable:!0,writable:!0}):n[i]=s}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(r)):o(Object(r)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(r,t))})}return e}function u(e){return"span"===e._type&&"text"in e&&"string"==typeof e.text&&(typeof e.marks>"u"||Array.isArray(e.marks)&&e.marks.every(e=>"string"==typeof e))}function c(e){return"string"==typeof e._type&&"@"!==e._type[0]&&(!("markDefs"in e)||!e.markDefs||Array.isArray(e.markDefs)&&e.markDefs.every(e=>"string"==typeof e._key))&&"children"in e&&Array.isArray(e.children)&&e.children.every(e=>"object"==typeof e&&"_type"in e)}function p(e){return c(e)&&"listItem"in e&&"string"==typeof e.listItem&&(typeof e.level>"u"||"number"==typeof e.level)}function d(e){return"@list"===e._type}function f(e){return"@span"===e._type}function m(e){return"@text"===e._type}let y=["strong","em","code","underline","strike-through"];function h(e,t,r){if(!u(e)||!e.marks||!e.marks.length)return[];let n=e.marks.slice(),i={};return n.forEach(e=>{i[e]=1;for(let n=t+1;n<r.length;n++){let t=r[n];if(t&&u(t)&&Array.isArray(t.marks)&&-1!==t.marks.indexOf(e))i[e]++;else break}}),n.sort((e,t)=>(function(e,t,r){let n=e[t],i=e[r];if(n!==i)return i-n;let s=y.indexOf(t),l=y.indexOf(r);return s!==l?s-l:t.localeCompare(r)})(i,e,t))}function g(e,t,r){return{_type:"@list",_key:`${e._key||`${t}`}-parent`,mode:r,level:e.level||1,listItem:e.listItem,children:[e]}}function b(e,t){let r=t.level||1,n=t.listItem||"normal",i="string"==typeof t.listItem;if(d(e)&&(e.level||1)===r&&i&&(e.listItem||"normal")===n)return e;if(!("children"in e))return;let s=e.children[e.children.length-1];return s&&!u(s)?b(s,t):void 0}var v=r(61120);let x=["block","list","listItem","marks","types"],k=["listItem"],j=["_key"];function _(e,t){var r=Object.keys(e);if(Object.getOwnPropertySymbols){var n=Object.getOwnPropertySymbols(e);t&&(n=n.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),r.push.apply(r,n)}return r}function w(e){for(var t=1;t<arguments.length;t++){var r=null!=arguments[t]?arguments[t]:{};t%2?_(Object(r),!0).forEach(function(t){var n,i,s;n=e,i=t,s=r[t],(i=function(e){var t=function(e,t){if("object"!=typeof e||!e)return e;var r=e[Symbol.toPrimitive];if(void 0!==r){var n=r.call(e,t||"default");if("object"!=typeof n)return n;throw TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(e,"string");return"symbol"==typeof t?t:t+""}(i))in n?Object.defineProperty(n,i,{value:s,enumerable:!0,configurable:!0,writable:!0}):n[i]=s}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(r)):_(Object(r)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(r,t))})}return e}function P(e,t){if(null==e)return{};var r,n,i=function(e,t){if(null==e)return{};var r={};for(var n in e)if(({}).hasOwnProperty.call(e,n)){if(t.includes(n))continue;r[n]=e[n]}return r}(e,t);if(Object.getOwnPropertySymbols){var s=Object.getOwnPropertySymbols(e);for(n=0;n<s.length;n++)r=s[n],t.includes(r)||({}).propertyIsEnumerable.call(e,r)&&(i[r]=e[r])}return i}let I={textDecoration:"underline"},O=(e,t)=>`[@portabletext/react] Unknown ${e}, specify a component for it in the \`components.${t}\` prop`,S=e=>O(`block type "${e}"`,"types"),A=e=>O(`mark type "${e}"`,"marks"),q=e=>O(`block style "${e}"`,"block"),E=e=>O(`list style "${e}"`,"list"),D=e=>O(`list item style "${e}"`,"listItem");function $(e){console.warn(e)}let T={display:"none"},M={types:{},block:{normal:({children:e})=>(0,n.jsx)("p",{children:e}),blockquote:({children:e})=>(0,n.jsx)("blockquote",{children:e}),h1:({children:e})=>(0,n.jsx)("h1",{children:e}),h2:({children:e})=>(0,n.jsx)("h2",{children:e}),h3:({children:e})=>(0,n.jsx)("h3",{children:e}),h4:({children:e})=>(0,n.jsx)("h4",{children:e}),h5:({children:e})=>(0,n.jsx)("h5",{children:e}),h6:({children:e})=>(0,n.jsx)("h6",{children:e})},marks:{em:({children:e})=>(0,n.jsx)("em",{children:e}),strong:({children:e})=>(0,n.jsx)("strong",{children:e}),code:({children:e})=>(0,n.jsx)("code",{children:e}),underline:({children:e})=>(0,n.jsx)("span",{style:I,children:e}),"strike-through":({children:e})=>(0,n.jsx)("del",{children:e}),link:({children:e,value:t})=>(0,n.jsx)("a",{href:t?.href,children:e})},list:{number:({children:e})=>(0,n.jsx)("ol",{children:e}),bullet:({children:e})=>(0,n.jsx)("ul",{children:e})},listItem:({children:e})=>(0,n.jsx)("li",{children:e}),hardBreak:()=>(0,n.jsx)("br",{}),unknownType:({value:e,isInline:t})=>{let r=S(e._type);return t?(0,n.jsx)("span",{style:T,children:r}):(0,n.jsx)("div",{style:T,children:r})},unknownMark:({markType:e,children:t})=>(0,n.jsx)("span",{className:`unknown__pt__mark__${e}`,children:t}),unknownList:({children:e})=>(0,n.jsx)("ul",{children:e}),unknownListItem:({children:e})=>(0,n.jsx)("li",{children:e}),unknownBlockStyle:({children:e})=>(0,n.jsx)("p",{children:e})};function C(e,t,r){let n=t[r],i=e[r];return"function"==typeof n||n&&"function"==typeof i?n:n?w(w({},i),n):i}function U({value:e,components:t,listNestingMode:r,onMissingComponent:i=$}){let s=i||L,l=function(e,t){let r,n=[];for(let l=0;l<e.length;l++){let o=e[l];if(o){var i,s;if(!p(o)){n.push(o),r=void 0;continue}if(!r){r=g(o,l,t),n.push(r);continue}if(i=o,s=r,(i.level||1)===s.level&&i.listItem===s.listItem){r.children.push(o);continue}if((o.level||1)>r.level){let e=g(o,l,t);if("html"===t){let t=r.children[r.children.length-1],n=a(a({},t),{},{children:[...t.children,e]});r.children[r.children.length-1]=n}else r.children.push(e);r=e;continue}if((o.level||1)<r.level){let e=n[n.length-1],i=e&&b(e,o);if(i){(r=i).children.push(o);continue}r=g(o,l,t),n.push(r);continue}if(o.listItem!==r.listItem){let e=n[n.length-1],i=e&&b(e,{level:o.level||1});if(i&&i.listItem===o.listItem){(r=i).children.push(o);continue}r=g(o,l,t),n.push(r);continue}console.warn("Unknown state encountered for block",o),n.push(o)}}return n}(Array.isArray(e)?e:[e],r||"html"),o=(0,v.useMemo)(()=>t?function(e,t){let{block:r,list:n,listItem:i,marks:s,types:l}=t,o=P(t,x);return w(w({},e),{},{block:C(e,t,"block"),list:C(e,t,"list"),listItem:C(e,t,"listItem"),marks:C(e,t,"marks"),types:C(e,t,"types")},o)}(M,t):M,[t]),u=(0,v.useMemo)(()=>N(o,s),[o,s]),c=l.map((e,t)=>u({node:e,index:t,isInline:!1,renderNode:u}));return(0,n.jsx)(n.Fragment,{children:c})}let N=(e,t)=>function r(i){let{node:s,index:l,isInline:o}=i,a=s._key||`node-${l}`;return d(s)?function(i,s,l){let o=i.children.map((e,t)=>r({node:e._key?e:w(w({},e),{},{_key:`li-${s}-${t}`}),index:t,isInline:!1,renderNode:r})),a=e.list,u=("function"==typeof a?a:a[i.listItem])||e.unknownList;if(u===e.unknownList){let e=i.listItem||"bullet";t(E(e),{nodeType:"listStyle",type:e})}return(0,n.jsx)(u,{value:i,index:s,isInline:!1,renderNode:r,children:o},l)}(s,l,a):p(s)?function(i,s,l){let o=B({node:i,index:s,isInline:!1,renderNode:r}),a=e.listItem,u=("function"==typeof a?a:a[i.listItem])||e.unknownListItem;if(u===e.unknownListItem){let e=i.listItem||"bullet";t(D(e),{type:e,nodeType:"listItemStyle"})}let c=o.children;if(i.style&&"normal"!==i.style){let{listItem:e}=i;c=r({node:P(i,k),index:s,isInline:!1,renderNode:r})}return(0,n.jsx)(u,{value:i,index:s,isInline:!1,renderNode:r,children:c},l)}(s,l,a):f(s)?function(i,s,l){let{markDef:o,markType:a,markKey:u}=i,c=e.marks[a]||e.unknownMark,p=i.children.map((e,t)=>r({node:e,index:t,isInline:!0,renderNode:r}));return c===e.unknownMark&&t(A(a),{nodeType:"mark",type:a}),(0,n.jsx)(c,{text:function e(t){let r="";return t.children.forEach(t=>{m(t)?r+=t.text:f(t)&&(r+=e(t))}),r}(i),value:o,markType:a,markKey:u,renderNode:r,children:p},l)}(s,0,a):s._type in e.types?function(t,i,s,l){let o=e.types[t._type];return o?(0,n.jsx)(o,w({},{value:t,isInline:l,index:i,renderNode:r}),s):null}(s,l,a,o):c(s)?function(i,s,l,o){let a=B({node:i,index:s,isInline:o,renderNode:r}),{_key:u}=a,c=P(a,j),p=c.node.style||"normal",d=("function"==typeof e.block?e.block:e.block[p])||e.unknownBlockStyle;return d===e.unknownBlockStyle&&t(q(p),{nodeType:"blockStyle",type:p}),(0,n.jsx)(d,w(w({},c),{},{value:c.node,renderNode:r}),l)}(s,l,a,o):m(s)?function(t,r){if(t.text===`
`){let t=e.hardBreak;return t?(0,n.jsx)(t,{},r):`
`}return t.text}(s,a):function(i,s,l,o){t(S(i._type),{nodeType:"block",type:i._type});let a=e.unknownType;return(0,n.jsx)(a,w({},{value:i,isInline:o,index:s,renderNode:r}),l)}(s,l,a,o)};function B(e){let{node:t,index:r,isInline:n,renderNode:i}=e,s=(function(e){var t,r;let{children:n}=e,i=null!=(t=e.markDefs)?t:[];if(!n||!n.length)return[];let s=n.map(h),l={_type:"@span",children:[],markType:"<unknown>"},o=[l];for(let e=0;e<n.length;e++){let t=n[e];if(!t)continue;let l=s[e]||[],a=1;if(o.length>1)for(;a<o.length;a++){let e=(null==(r=o[a])?void 0:r.markKey)||"",t=l.indexOf(e);if(-1===t)break;l.splice(t,1)}let c=(o=o.slice(0,a))[o.length-1];if(c){for(let e of l){let r=null==i?void 0:i.find(t=>t._key===e),n=r?r._type:e,s={_type:"@span",_key:t._key,children:[],markDef:r,markType:n,markKey:e};c.children.push(s),o.push(s),c=s}if(u(t)){let e=t.text.split(`
`);for(let t=e.length;t-- >1;)e.splice(t,0,`
`);c.children=c.children.concat(e.map(e=>({_type:"@text",text:e})))}else c.children=c.children.concat(t)}}return l.children})(t).map((e,t)=>i({node:e,isInline:!0,index:t,renderNode:i}));return{_key:t._key||`block-${r}`,children:s,index:r,isInline:n,node:t}}function L(){}var R=r(36162);async function G({params:e}){let t=await (0,s.TS)(e.slug);return t?(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{children:(0,n.jsx)(i.A,{title:t.title,subtitle:"Blog Detail"})}),(0,n.jsxs)("div",{className:"container space-y-6 py-10",children:[(0,n.jsxs)("div",{className:"blog-meta",children:[(0,n.jsxs)("a",{className:"author",href:`/blog/${t.slug.current}`,children:[(0,n.jsx)("i",{className:"fal fa-user"}),"By Mamigas"]}),(0,n.jsxs)("a",{href:`/blog/${t.slug.current}`,children:[(0,n.jsx)("i",{className:"fal fa-calendar"}),new Date(t.publishedAt).toLocaleDateString()]})]}),t.mainImage&&(0,n.jsx)("img",{src:(0,l.i)(t.mainImage).url(),alt:t.title,className:"w-full max-h-[400px] object-cover rounded-xl"}),(0,n.jsx)("div",{className:"prose max-w-full",children:(0,n.jsx)(U,{value:t.body})})]}),(0,n.jsx)(R.default,{src:"/assets/js/main.js",strategy:"afterInteractive"})]}):(0,n.jsx)("div",{children:"Blog not found."})}},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},88202:(e,t,r)=>{"use strict";r.d(t,{AS:()=>g,Fh:()=>b,g6:()=>d,vB:()=>h,bW:()=>y,n0:()=>m,TS:()=>f});var n=r(99902),i=r(98810);let s=(0,i.E)(`*[_type == "post"] | order(publishedAt desc) {
  title,
  slug,
  mainImage,
  excerpt,
  publishedAt,
  "categories": categories[]->title
}
`),l=(0,i.E)(`
  *[_type == "post" && slug.current == $slug][0]{
    title,
    slug,
    publishedAt,
    mainImage,
    body,
  }
  `),o=(0,i.E)(`*[_type == "post"] | order(publishedAt desc)[0...3] {
  title,
  slug,
  mainImage,
  publishedAt
}
`);(0,i.E)(`
    *[_type == "post" && references(*[_type == "category" && title == $category]._id)] {
      title,
      slug,
      mainImage,
      publishedAt
    }
  `);let a=(0,i.E)(`*[_type == "category"] | order(title asc) {
  _id,
  title,
  slug
}
`),u=(0,i.E)(`
  *[_type == "post" && $slug in categories[]->slug.current] | order(publishedAt desc) {
    title,
    slug,
    mainImage,
    excerpt,
    publishedAt,
    "categories": categories[]->title
  }
`),c=(0,i.E)(`*[_type == "product"]{
  _id,
  title,
  slug,
  description,
  price,
  stock,
  "imageUrl": image.asset->url,
  publishedAt,
  category->{
    _id,
    title
  }
} | order(publishedAt desc)`),p=(0,i.E)(`
  *[_type == "productCategory"]{
  _id,
  title,
  slug,
  description
} | order(title asc)
`);(0,i.E)(`
  *[_type == "product" && slug.current == $slug][0]{
  _id,
  title,
  slug,
  image,
  description,
  price,
  stock,
  publishedAt,
  "category": category->{
    _id,
    title
  }
}
`),(0,i.E)(`*[_type == "product" && category->slug.current == $categorySlug]{
  _id,
  title,
  slug,
  image,
  description,
  price,
  stock,
  publishedAt,
  "category": category->{
    _id,
    title,
    slug
  }
}
`);let d=async()=>await n.S.fetch(s),f=async e=>await n.S.fetch(l,{slug:e}),m=async()=>await n.S.fetch(o),y=async()=>await n.S.fetch(a),h=async e=>await n.S.fetch(u,{slug:e}),g=async()=>await n.S.fetch(c),b=async()=>await n.S.fetch(p)},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},99902:(e,t,r)=>{"use strict";r.d(t,{S:()=>n});let n=(0,r(25588).UU)({projectId:"xfohgy13",dataset:"production",apiVersion:"2025-05-27",useCdn:!0})}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[447,182,491,739,777,667],()=>r(28534));module.exports=n})();